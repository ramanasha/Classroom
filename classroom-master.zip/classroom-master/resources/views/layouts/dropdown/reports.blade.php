<li class="dropdown">
    <a herf="#" class="dropdown-toggle" role="button" id="report" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
        Payment Report
        <span class="caret"></span>
    </a>
    <ul class="dropdown-menu" aria-labelledby="report">
        <li><a href="{{ action("ReportController@index") }}">Reports</a></li>
    </ul>
</li>