### School Management System
~- Register a Student
~- Setup Payment
~- Assign to Batch
~- View Listing of Batches with student list
- Payment Report for Batch

### TODO
- Validation Rules	
	- student request
	- batch request
	- report request
- Datatable Implements
